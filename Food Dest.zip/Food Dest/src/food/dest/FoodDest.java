/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package food.dest;

import java.sql.Connection;
import java.sql.*;

/**
 *
 * @author Hp
 */
public class FoodDest {

    private static Connection NULL;

    /**
     * @param args the command line arguments
     */
    public static Connection main(String[] args) {
        // TODO code application logic here
        Connection con=null;
        try
        {
            Class.forName("com.mysql.jdbc.Driver");
            con=DriverManager.getConnection("jdbc:mysql://localhost:3306/user_db");
            
        }
        catch(ClassNotFoundException | SQLException e)
        {
            System.out.println(e);
        }
        return con;
    }

    public static Connection connect() {
        System.out.println(); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
        return NULL;
    }
    
}